@extends('ujian.main')
@section('title', 'Prodi')

@section('konten')
    <div>
        <h1>Sistem  Informasi</h1>
        <p>Bidang studi yang berkaitan dengan teknologi informasi, pengelolaan data, dan sistem komputer dalam organisasi.</p>
    </div>
@endsection