@extends('ujian.main')
@section('title', 'Home')

@section('konten')
    <div class="container w-75 d-flex align-items-center flex-column">
        disini adalah homepage<br>
        Gambar: <br>
        <img class="shadow rounded-2" src="{{ asset('assets/img/Rui.jpeg') }}" alt="gambar">
    </div>
@endsection