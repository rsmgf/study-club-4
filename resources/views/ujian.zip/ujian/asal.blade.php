@extends('ujian.main')
@section('title', 'Asal Daerah')

@section('konten')
    <div>
        <h1>Jambi</h1>
        <p>Kota atau provinsi asal Raihan Sanovra, yang berada di Indonesia.</p>
    </div>
@endsection