@extends('latihan2.template')

@section('title', 'Dashboard')

@section('konten')
    <h2>Dashboard</h2>
    <p>Selamat Datang di Halaman Dashboard</p>
@endsection