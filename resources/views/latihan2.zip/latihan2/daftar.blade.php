@extends('latihan2.template')

@section('title', 'Daftar')

@section('konten')
    <h2>Daftar</h2>
    <p>This is daftar</p>
@endsection