@extends('ujian.main')
@section('title', 'Angkatan')

@section('konten')
    <div>
        <h1>2023</h1>
        <p>Tahun masuk kuliah, menunjukkan bahwa Raihan Sanovra mulai studi di perguruan tinggi pada tahun 2023.</p>
    </div>
@endsection